import math
print("Angle\tSin\t\tCos\t\tTan")
for angle in range(0, 91, 15):
    rad = math.radians(angle)
    print(angle, "\t\t", round(math.sin(rad), 2), "\t", round(math.cos(rad), 2), "\t", end='')
    if angle == 90:
        print("undefined")
    else:
        print(round(math.tan(rad), 2))
