from datetime import date
# Two dates
d1 = date(2025, 9, 6)
d2 = date(2024, 1, 1)
# Find difference
diff = d1 - d2
print("Difference in days:", diff.days)
