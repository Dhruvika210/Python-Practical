# 1. Concatenation
str1 = "Hello"
str2 = "World"
result = str1 + " " + str2
print("1. Concatenation:", result)  # Hello World

# 2. String Formatting
name = "Alice"
age = 30
formatted = f"My name is {name} and I am {age} years old."
print("2. String Formatting:", formatted)

# 3. Changing Case
text = "hello world"
print("3. Upper Case:", text.upper())         # HELLO WORLD
print("   Lower Case:", text.lower())         # hello world
print("   Title Case:", text.title())         # Hello World
print("   Capitalize:", text.capitalize())    # Hello world

# 4. Splitting and Joining
sentence = "Python is awesome"
words = sentence.split()
print("4. Splitting:", words)                 # ['Python', 'is', 'awesome']
joined = "-".join(words)
print("   Joining:", joined)                  # Python-is-awesome

# 5. Replacing Substrings
text = "I love Java"
new_text = text.replace("Java", "Python")
print("5. Replacing:", new_text)              # I love Python

# 6. Removing Whitespace
text = "  Hello World  "
print("6. Strip:", text.strip())              # 'Hello World'
print("   LStrip:", text.lstrip())            # 'Hello World  '
print("   RStrip:", text.rstrip())            # '  Hello World'

# 7. Checking for Substrings
text = "Python programming"
print("7. 'Python' in text:", "Python" in text)     # True
print("   'Java' not in text:", "Java" not in text) # True

# 8. String Slicing
text = "Hello, World!"
print("8. text[0:5]:", text[0:5])              # Hello
print("   text[:5]:", text[:5])                # Hello
print("   text[7:]:", text[7:])                # World!
print("   text[-6:]:", text[-6:])              # World!

# 9. Reversing a String
text = "Python"
reversed_text = text[::-1]
print("9. Reversed:", reversed_text)          # nohtyP

# 10. Checking Prefix/Suffix
filename = "example.txt"
print("10. Starts with 'ex':", filename.startswith("ex"))  # True
print("    Ends with '.txt':", filename.endswith(".txt"))  # True
