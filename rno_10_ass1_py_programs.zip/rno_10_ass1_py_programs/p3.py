from datetime import date
# Replace with your birthdate
birth = date(2005, 5, 20)
today = date.today()
years = today.year - birth.year
months = today.month - birth.month
days = today.day - birth.day
if days < 0:
    months -= 1
    days += 30
if months < 0:
    years -= 1
    months += 12
print("Your age is:", years, "years", months, "months", days, "days")
