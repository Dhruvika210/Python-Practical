def encrypt(text):
    key = 5
    return ''.join(chr(ord(c) ^ key) for c in text)
# Stored credentials (encrypted)
stored_user = encrypt("admin")
stored_pass = encrypt("1234")
# Input from user
user = input("Username: ")
pwd = input("Password: ")
if encrypt(user) == stored_user and encrypt(pwd) == stored_pass:
    print("Login successful!")
else:
    print("Login failed!")
