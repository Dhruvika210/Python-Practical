import hashlib
def hash_value(text):
    return hashlib.sha256(text.encode()).hexdigest()
stored_user = hash_value("admin")
stored_pass = hash_value("1234")
user = input("Username: ")
pwd = input("Password: ")
if hash_value(user) == stored_user and hash_value(pwd) == stored_pass:
    print("Login successful!")
else:
    print("Login failed!")
