import time
# Time since Jan 1, 1970
seconds = time.time()
hours = int(seconds // 3600)
minutes = int((seconds % 3600) // 60)
print("Time since epoch:", hours, "hours and", minutes, "minutes")
